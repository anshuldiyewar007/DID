---
title: Hello World
date: "2019-02-24T22:12:03.284Z"
image: "/imgs/micro_6.jpg"
---

This GitHub DID documentation website is build with [Gatsby.js](https://www.gatsbyjs.org/). Its mostly just Markdown, GraphQL and React. 

Our hope is that its ease of use will encourage contributions.