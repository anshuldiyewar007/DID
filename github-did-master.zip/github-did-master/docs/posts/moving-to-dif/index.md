---
title: Moving to DIF
date: "2019-04-29T22:12:03.284Z"
image: "/imgs/micro_7.jpg"
---

We're moving GitHub DID to the [DIF](https://identity.foundation/)!

[New Repo URL](https://github.com/decentralized-identity/github-did)