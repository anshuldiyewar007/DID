---
title: Signatures
date: "2019-02-24T22:12:03.284Z"
---

In this tutorial, we'll walk you through signing and verifying with GitHub DID.

