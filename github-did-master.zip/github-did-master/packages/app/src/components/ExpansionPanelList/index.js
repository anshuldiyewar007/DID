import ExpansionPanelList from './ExpansionPanelList';

export default ExpansionPanelList;
