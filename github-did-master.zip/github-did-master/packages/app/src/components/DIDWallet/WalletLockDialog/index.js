import WalletLockDialog from './WalletLockDialog';

export default WalletLockDialog;
