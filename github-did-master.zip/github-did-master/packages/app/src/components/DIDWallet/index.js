import DIDWallet from './DIDWallet';

import wallet from '../../redux/wallet';

export default wallet.container(DIDWallet);
