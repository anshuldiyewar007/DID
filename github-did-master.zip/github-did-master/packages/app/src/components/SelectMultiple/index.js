import SelectMultiple from './SelectMultiple';

export default SelectMultiple;
