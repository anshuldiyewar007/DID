import DIDResolver from './DIDResolver';

import did from '../../redux/did';

export default did.container(DIDResolver);
