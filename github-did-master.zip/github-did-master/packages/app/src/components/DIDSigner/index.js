import DIDSigner from './DIDSigner';

import wallet from '../../redux/wallet';

export default wallet.container(DIDSigner);
