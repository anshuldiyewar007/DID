import DisplayPayloadDialog from './DisplayPayloadDialog';

export default DisplayPayloadDialog;
