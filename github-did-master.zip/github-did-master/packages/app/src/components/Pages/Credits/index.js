import Credits from './Credits';

export default Credits;
