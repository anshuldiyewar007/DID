import { withRouter } from 'react-router';

import Sign from './Sign';

export default withRouter(Sign);
