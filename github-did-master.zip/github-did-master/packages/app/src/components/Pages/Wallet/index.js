import Wallet from './Wallet';

export default Wallet;
