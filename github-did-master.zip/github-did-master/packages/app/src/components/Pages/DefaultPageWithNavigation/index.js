import DefaultPageWithNavigation from './DefaultPageWithNavigation';

export default DefaultPageWithNavigation;
