import Resolver from './Resolver';

export default Resolver;
