import { withRouter } from 'react-router';

import Verify from './Verify';

export default withRouter(Verify);
