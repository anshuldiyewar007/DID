import { withRouter } from 'react-router';

import Decrypt from './Decrypt';

export default withRouter(Decrypt);
