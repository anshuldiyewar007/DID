import { withRouter } from 'react-router';

import Encrypt from './Encrypt';

export default withRouter(Encrypt);
