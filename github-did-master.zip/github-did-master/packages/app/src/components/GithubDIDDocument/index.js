import GithubDIDDocument from './GithubDIDDocument';

import snackbar from '../../redux/snackbar';

export default snackbar.container(GithubDIDDocument);
