import DIDVerifer from './DIDVerifer';

import wallet from '../../redux/wallet';

export default wallet.container(DIDVerifer);
