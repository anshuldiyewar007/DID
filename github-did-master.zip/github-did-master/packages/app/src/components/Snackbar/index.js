import Snackbar from './Snackbar';

import snackbar from '../../redux/snackbar';

export default snackbar.container(Snackbar);
