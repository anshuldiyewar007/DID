import ParticlesContainer from './ParticlesContainer';

export default ParticlesContainer;
