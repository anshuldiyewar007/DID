import DIDEncrypter from './DIDEncrypter';

import wallet from '../../redux/wallet';

export default wallet.container(DIDEncrypter);
