import { compose } from 'recompose';

import withRedux from './redux';

export default compose(withRedux);
