import * as actions from './actions';
import reducer from './reducer';
import container from './container';

export default {
  actions,
  reducer,
  container,
};
