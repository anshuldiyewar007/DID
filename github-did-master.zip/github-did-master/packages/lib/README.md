# @github-did/lib

A library for working with DIDs using Github!


### Development

```bash
npm i
npm run test
```

